
const hamburger = document.querySelector('.hamburger');
const menu_bar = document.querySelector('.menu-bar');


const head = document.querySelector('.head');
const click_audio = document.getElementById('click-sound-effect');
const buttons = document.querySelectorAll('.button');


const menu_produk = document.querySelector('.halaman');


const scroll_up = document.querySelector('.scroll-up');
const container_scroll_up = document.querySelector('.container-scroll-up');

// const last_element = document.querySelector('.isi');
let isScrollListenerActive = true;

hamburger.addEventListener('click',function(){
    if(menu_bar.classList.contains('show')){
        menu_bar.classList.remove('show');
    }else{
        menu_bar.classList.add('show');
    }
});




// window.addEventListener('scroll',function (){
    
//     const PositionWindow = window.scrollY;
//     const PositionScrollShow = last_element.offsetTop ;
//     if(PositionWindow >= PositionScrollShow){
//         scroll_up.classList.add('show2');
//     }else{
//         scroll_up.classList.remove('show2');
//     }
// });


scroll_up.addEventListener('click',function(){
    if(!scroll_up.classList.contains('hilang-smooth')){
        window.scrollTo({
            top:0,
            behavior:'smooth'
        })
    }
});




click_audio.volume = 0.4;
buttons.forEach(function(el){
    el.addEventListener('mousedown',function(){
        click_audio.currentTime = 0;
        click_audio.play();
    })
});












