<?php session_start(); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>wfdigistore</title>
    <link rel="stylesheet" href="../produk/wf.css">
    <link rel="icon" type="image/png" href="wf-logo-icon.png">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lilita+One&display=swap" rel="stylesheet">

</head>
<body>
    <div class="halaman" >
        <div class="head-menu">
            <div class="head">
                <img class="wf-logo" src="wf-logo.png" alt="wfdigistore logo">
                <div class="navs">
                    <a href="../produk/" class="button"><div class="nav">Produk</div></a>
                    <div class="nav">Pesanan</div>
                    <div class="nav">Keranjang</div>
                    <a href="../bantuan/" class="button"><div class="nav"> Bantuan</div></a>
                </div>
                    <?php if(!isset($_SESSION['user_id'])): ?>
                    <a href="../sign-in" class="button">
                        <div class="sign-in s1">Sign in</div>
                    </a>
                    <?php elseif (isset($_SESSION['user_id'])): ?>
                        <div class="right-nav">
                            <div class="sign-in s1 profile">
                                Hello , <?php echo $_SESSION['name'] ?>
                                <img class = "profile-icon" src="../profile.png" alt="icon-profile">
                            </div>
                            <img class="logout-icon s1" src="../logout-icon.png" alt="exit">
                        </div>
                    <?php endif; ?>
                    <div class="hamburger button">☰</div>
            </div>
        
            <div class="menu-bar">
                <a href="../produk/" class="button"><div class="nav">Produk</div></a>
                <div class="nav">Pesanan</div>
                <div class="nav">Keranjang</div>
                <a href="../bantuan/" class="button"><div class="nav"> Bantuan</div></a>
                <a href="../sign-in" class="button">
                    <div class="sign-in s2 button">Sign in</div>
                </a>
                
            </div>

            
        </div>

            <div class="text">
                <h1 class="judul">Pertanyaan Umum</h1>
                <div class="garis_awal"></div>
            </div>

            <div class="isi">
                <div class="pertanyaan">

                    <div class="kotak_tanya" role="button" tabindex="0" aria-expanded="false">
                        <h1 class="tanya">Apa itu Wfdigistore?</h1>
                        <img src="arrow.png" alt="open-modal-arrow" class="arrow">
                    </div>
                    <div class="jawaban">
                        <p>Wfdigistore adalah toko digital yang menyediakan e-book, template, dan produk digital lainnya. Pembayaran dilakukan melalui metode yang tersedia di checkout.</p>
                    </div>
                    <div class="garis"></div>

                    <br>
        
                    <div class="kotak_tanya" role="button" tabindex="0" aria-expanded="false">
                        <h1 class="tanya">Kenapa Wfdigistore?</h1>
                        <img src="arrow.png" alt="open-modal-arrow" class="arrow">
                    </div>
                    <div class="jawaban">
                        <p>g menyediakan e-book, template, dan produk digital lainnya. Pembayaran dilag menyediakan e-book, template, dan produk digital lainnya. Pembayaran dilaWfdigistore adalah toko digital yang menyediakan e-book, template, dan produk digital lainnya. Pembayaran dilakukan melalui metode yang tersedia di checkout.</p>
                    </div>
                    <div class="garis"></div>

                    <br>
        
                    <div class="kotak_tanya" role="button" tabindex="0" aria-expanded="false" >
                        <h1 class="tanya">Apakah Wfdigistore aman?</h1>
                        <img src="arrow.png" alt="open-modal-arrow" class="arrow">
                    </div>
                    <div class="jawaban">
                        <p>g menyediakan e-book, template, dan produk digital lainnya. Pembayaran dilag menyediakan e-book, template, dan produk digital lainnya. Pembayaran dilaWfdigistore adalah toko digital yang menyediakan e-book, template, dan produk digital lainnya. Pembayaran dilakukan melalui metode yang tersedia di checkout.</p>
                    </div>
                    <div class="garis"></div>

                    <br>
        
                    <div class="kotak_tanya" role="button" tabindex="0" aria-expanded="false">
                        <h1 class="tanya">coba?</h1>
                        <img src="arrow.png" alt="open-modal-arrow" class="arrow">
                    </div>
                    <div class="jawaban">
                        <p>g menyediakan e-book, template, dan produk digital lainnya. Pembayaran dilag menyediakan e-book, template, dan produk digital lainnya. Pembayaran dilaWfdigistore adalah toko digital yang menyediakan e-book, template, dan produk digital lainnya. Pembayaran dilakukan melalui metode yang tersedia di checkout.</p>
                    </div>
                    <div class="garis"></div>
                    
                    

                </div>
            </div>

            <div class="lower">
            
                <div class="isi_lower">
                    <div class="judul_lower">
                        <h3>Tidak menemukan jawaban yang kamu cari?</h3>
                        <p>Jangan ragu untuk bertanya, dan kami akan dengan sigap membantu Anda</p>
                    </div>
                    
                    <div class="sub_judul">
                        
                    </div>
                    <a href="https://api.whatsapp.com/send/?phone=%2B6281318817484&text&type=phone_number&app_absent=0"><button class="hubungi">Hubungi Admin</button></a>
                </div>
            </div>
        


    </div>
    
    <div class="container-scroll-up">
        <img class="scroll-up  button" src="../return.png" alt="scroll-up arrow"></img>
    </div>
</body>
<audio id = "click-sound-effect" src="../click-sound-effect.wav"></audio>
<script src="test.js"></script>
</html>